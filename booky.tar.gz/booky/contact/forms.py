from django import forms
from django.core.exceptions import ValidationError
from .models import *
from django.contrib.auth.models import User










class NewUserForm(forms.ModelForm):
    modpas = forms.CharField(widget=forms.PasswordInput)
    modpas2 = forms.CharField(widget=forms.PasswordInput)
    class Meta:
        model = NewUser
        fields=("__all__")


    def clean(self):
        cleaned_data = super().clean()
        non = cleaned_data['non']
        modpas = cleaned_data['modpas']
        modpas2 = cleaned_data['modpas2']



        if len(modpas)<8:
            self.add_error('modpas','Modpas la  dwe gen 8 karakte minimom')

        if modpas2 != modpas:
            self.add_error('modpas2','modpas enkorek!')

    
        

       




