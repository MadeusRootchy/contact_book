from django.shortcuts import redirect, get_object_or_404, render
from django.http import HttpResponse,Http404
from .models import *
from .forms import *
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from django.db.utils import IntegrityError
# Create your views here.
def akey(request):
    konekte = request.user.is_authenticated
    context={
        'konekte':konekte
    }
    return render(request,'base.html',context)


def konekte(request):
    if not request.user.is_authenticated:
            
        if request.method =='POST':
            non = request.POST.get("non")
            modpas = request.POST.get("modpas")
            user = authenticate(username=non,password=modpas)

            if user is not None:
                login(request,user)
                print('identifikasyon an fet')
                return redirect(akey)
            else:
                print('idantifyan yo pa korek...')


        context={}
        return render(request,'konekte.html',context)

    else:
        return redirect(akey)


def dekonekte(request):
    if request.user.is_authenticated:
        logout(request)
        return redirect(akey)
    else:
        return redirect(akey)



def newuser(request):
    if request.method =='POST':
        form = NewUserForm(data=request.POST)
        if form.is_valid():
            try:
                non = form.cleaned_data.get('non')
                modpas = form.cleaned_data.get('modpas')
                modpas2 = form.cleaned_data.get('modpas2')
                user = User.objects.create_user(username=non,password=modpas)
                user.save()
            except IntegrityError:
                pass
            return redirect(akey)
        else:
            print('fomile a gen ere')
            
    else:
        form = NewUserForm()
    context={
        'form':form
    }
    return render(request,'newuser.html',context) 



def index(request):
    contacts = Contact.objects.all()
    search_input = request.GET.get('search-area')
    if search_input:
        contacts = Contact.objects.filter(full_name__icontains=search_input)
    else:
        contacts = Contact.objects.all()
        search_input = ''
    return render(request, 'index.html', {'contacts': contacts, 'search_input': search_input})

def addContact(request):
    if request.user.is_authenticated:
        if request.method == 'POST':

            new_contact = Contact(
                full_name=request.POST['fullname'],
                relationship=request.POST['relationship'],
                email=request.POST['email'],
                phone_number=request.POST['phone-number'],
                address=request.POST['address'],
                )
            new_contact.save()
            return redirect('/')

        return render(request, 'new.html')
    else:
        return redirect(konekte)

def editContact(request, pk):
    contact = Contact.objects.get(id=pk)
    if request.user.is_authenticated:
        if request.method == 'POST':
            contact.full_name = request.POST['fullname']
            contact.relationship = request.POST['relationship']
            contact.email = request.POST['email']
            contact.phone_number = request.POST['phone-number']
            contact.address = request.POST['address']
            contact.save()

            return redirect('/profile/'+str(contact.id))
        return render(request, 'edit.html', {'contact': contact})
    else:
        return redirect(konekte)

def deleteContact(request, pk):
    contact = Contact.objects.get(id=pk)
    if request.user.is_authenticated:

        if request.method == 'POST':
            contact.delete()
            return redirect('/')

        return render(request, 'delete.html', {'contact': contact})
    else:
        return redirect(konekte)
def contactProfile(request, pk):
    contact = Contact.objects.get(id=pk)
    return render(request, 'contact-profile.html', {'contact':contact})